
public class Engenheiro extends Funcionario {

	
	private String crea;

	public String getCrea() {
		return crea;
	}

	public void setCrea(String crea) {
		this.crea = crea;
	}
	
}
