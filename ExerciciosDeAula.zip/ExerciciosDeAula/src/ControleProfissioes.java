
public class ControleProfissioes {

	public static void main(String[] args) {
		
		Medico med1 = new Medico();
		Endereco endMed1 = new Endereco();
		Endereco enAdv1 = new Endereco();
		Endereco endEng1 = new Endereco();
	    //Advogado adv1 = new Advogado();
	    //Engenheiro eng1 = new Engenheiro();
	    
	    med1.setNome("Regina Duarte");
	    med1.setCrm("12.34567-0");
	    med1.setSalario(12000.00);
	    med1.setIdade(42);
	    med1.setCpf("123.456.789-00");
	   
	    med1.endereco = endMed1;
	    
	   
	    
	    med1.endereco.setNumero(230);
	    med1.endereco.setComplemento("Apto.701");
	    med1.endereco.setBairro("Flamengo");
	    med1.endereco.setCidade("Rio de Janeiro");
	    med1.endereco.setEstado("Rio de Janeiro");
	    med1.endereco.setCep("22230-001");
	    
	    
	    System.out.println("Nome: " + med1.getNome());
	    System.out.println("Idade" + med1.getIdade());
	    System.out.println("CPF: " + med1.getCrm());
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    
	}

}
