
public class Advogado extends Funcionario {

	private String oab;

	public String getOab() {
		return oab;
	}

	public void setOab(String oab) {
		this.oab = oab;
	}
	
	
	
}
